from pathlib import Path
import beingbeyond_d1_sdk as _pkg

_ASSETS_DIR = Path(_pkg.__file__).resolve().parent / "assets" / "beingbeyond_d1"

def get_default_urdf_path() -> str:
    return str(_ASSETS_DIR / "robot_right_hand.urdf")