import time
import os
import subprocess
from .core._dex_hand_core import HandApi


def _run(cmd: str, stdin_text = None):
    import shlex
    p = subprocess.run(shlex.split(cmd), input=stdin_text, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return p.returncode, (p.stdout or "").strip()

def _sudo(cmd: str):
    pw = os.environ.get("PREFLIGHT_SUDO_PASS", "")
    if pw:
        return _run(f"sudo -S {cmd}", stdin_text=pw + "\n")
    return _run(f"sudo {cmd}")

def _can_state(iface: str):
    p = f"/sys/class/net/{iface}/operstate"
    try:
        with open(p, "r") as f:
            return f.read().strip()
    except Exception:
        return None

def _ensure_can_up(iface: str, bitrate: int, restart_ms: int = 100, require_root: bool = False) -> str:
    st = _can_state(iface)
    if st not in ("up", "unknown"):
        cmd_down = f"/usr/sbin/ip link set {iface} down"
        cmd_type = f"/usr/sbin/ip link set {iface} type can bitrate {bitrate} restart-ms {restart_ms}"
        cmd_up   = f"/usr/sbin/ip link set {iface} up"
        run = _run if (os.geteuid()==0 and not require_root) else _sudo
        run(cmd_down)
        rc2, out2 = run(cmd_type)
        if rc2 != 0:
            raise RuntimeError(f"CAN config failed: {out2}")
        rc3, out3 = run(cmd_up)
        if rc3 != 0:
            raise RuntimeError(f"CAN up failed: {out3}")
        time.sleep(0.2)
    return iface

def _clip(v, lo, hi):
    return max(lo, min(v, hi))

class DexHand:
    def __init__(self, hand_type, can_iface, baudrate=1000000):
        iface = _ensure_can_up(iface=can_iface, bitrate=baudrate, restart_ms=100)
        self.hand = HandApi(hand_type=hand_type, can=iface, baudrate=baudrate)
        self.joint_names = ["thumb_cmc_pitch", "thumb_cmc_yaw", "index_mcp_pitch",
                            "middle_mcp_pitch", "ring_mcp_pitch", "pinky_mcp_pitch"]
        self.num_joints = len(self.joint_names)

        self.hardware_joint_limit_low = [0, 0, 0, 0, 0, 0]
        self.hardware_joint_limit_high = [255, 255, 255, 255, 255, 255]

    def read_joint_pos(self):
        """
        return:
            joint_pos: (D,) list in [0,1]
            1 = closed, 0 = open
        """
        data = self.hand.get_state()[:self.num_joints]
        joint_pos = []
        for i, d in enumerate(data):
            lo = self.hardware_joint_limit_low[i]
            hi = self.hardware_joint_limit_high[i]
            val = (d - lo) / (hi - lo) if hi != lo else 0.0
            val = _clip(val, 0.0, 1.0)
            joint_pos.append(1.0 - val)
        return joint_pos

    def set_joint_pos(self, joint_pos):
        """
        joint_pos: (D,) list in [0,1]
        """
        data = []
        for i, jp in enumerate(joint_pos):
            lo = self.hardware_joint_limit_low[i]
            hi = self.hardware_joint_limit_high[i]
            inv = 1.0 - _clip(jp, 0.0, 1.0)
            val = inv * (hi - lo) + lo
            data.append(int(_clip(val, 0, 255)))
        self.hand.finger_move(pose=data)

    def set_speed(self, speed):
        """
        speed: (D,) list in [0,1]
            1 = max speed, 0 = min speed
        """
        data = []
        for i, sp in enumerate(speed):
            val = _clip(sp, 0.0, 1.0)
            val = val * 255.0
            val = int(round(_clip(val, 0.0, 255.0)))
            data.append(val)
        self.hand.set_speed(speed=data)

    def get_speed(self):
        """
        return:
            speed: (D,) list in [0,1]
            1 = max speed, 0 = min speed
        """
        raw = self.hand.get_speed()[:self.num_joints]
        speed = []
        for i, d in enumerate(raw):
            lo, hi = 0.0, 255.0
            val = (d - lo) / (hi - lo) if hi != lo else 0.0
            val = _clip(val, 0.0, 1.0)
            speed.append(val)
        return speed

    def set_torque(self, torque):
        """
        torque: (D,) list in [0,1]
            1 = max torque, 0 = min torque
        """
        data = []
        for i, tq in enumerate(torque):
            val = _clip(tq, 0.0, 1.0)
            val = val * 255.0
            val = int(round(_clip(val, 0.0, 255.0)))
            data.append(val)
        self.hand.set_torque(torque=data)

    def get_torque(self):
        """
        return:
            torque: (D,) list in [0,1]
            1 = max torque, 0 = min torque
        """
        raw = self.hand.get_torque()[:self.num_joints]
        torque = []
        for i, d in enumerate(raw):
            lo, hi = 0.0, 255.0
            val = (d - lo) / (hi - lo) if hi != lo else 0.0
            val = _clip(val, 0.0, 1.0)
            torque.append(val)
        return torque

    def close_can(self):
        self.hand.close_can()

    def open_hand(self):
        n = getattr(self.hand, "num_joints", 6)
        p = [0.0] * n
        self.set_joint_pos(p)
        time.sleep(0.1)

    def half_close_hand(self):
        n = getattr(self.hand, "num_joints", 6)
        p = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
        self.set_joint_pos(p)
        time.sleep(0.1)

    def gesture_dance(self, duration_s: float, m: float = 0.1, interval_s: float = 0.1, start=None, ):
        if start is None:
            start = [0.0, 0.4, 0.4, 0.6, 0.8, 1.0]

        if len(start) != self.num_joints:
            raise ValueError(f"start length must be {self.num_joints}, got {len(start)}")

        lo = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        hi = [0.4, 0.4, 1.0, 1.0, 1.0, 1.0]

        cur = []
        for i, v in enumerate(start):
            if v < lo[i]:
                v = lo[i]
            elif v > hi[i]:
                v = hi[i]
            cur.append(v)

        direction = [-1.0] * len(cur)

        t_end = time.time() + duration_s

        while time.time() < t_end:
            self.set_joint_pos(cur)
            time.sleep(interval_s)
            for i in range(len(cur)):
                cur[i] += direction[i] * m
                if cur[i] <= lo[i]:
                    cur[i] = lo[i]
                    direction[i] = 1.0
                elif cur[i] >= hi[i]:
                    cur[i] = hi[i]
                    direction[i] = -1.0

if __name__ == '__main__':

    right = DexHand(hand_type="right", can_iface="can0")

    try:
        right.gesture_dance(duration_s=3, m=0.1, interval_s=0.1)

        right.open_hand()

        right.set_speed(speed=[1,1,1,1,1,1])
        right.set_torque(torque=[1,1,1,1,1,1])

        right.set_joint_pos([0.55,0.8,0.42,0.45,0,0])
        time.sleep(1)
        right.open_hand()
        time.sleep(1)

        right.get_torque()
        right.get_speed()

        right.set_speed(speed=[0.1,0.1,0.1,0.1,0.1,0.1])
        right.set_torque(torque=[0.1,0.1,0.1,0.1,0.1,0.1])

        right.set_joint_pos([0.55,0.8,0.42,0.45,0,0])
        time.sleep(5)

        right.set_speed(speed=[1,1,1,1,1,1])
        right.set_torque(torque=[1,1,1,1,1,1])


        print(right.read_joint_pos())
        time.sleep(1)
        right.half_close_hand()
        print(right.read_joint_pos())

        # right.open_hand()


    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Error: {e}")

    finally:
        try:
            safe_open = [0.0] *6
            right.set_joint_pos(safe_open)
            time.sleep(0.1)
        except Exception as e:
            print(f"Failed to send safe-open: {e}")
        try:
            right.close_can()
        except Exception as e:
            print(f"Failed to close: {e}")
