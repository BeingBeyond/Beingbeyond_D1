import math
from typing import Sequence, List, Optional, Iterable, Tuple

from .core._head_arm_core import HeadArmCore


def deg_list_to_rad(xs: Sequence[float]) -> List[float]:
    return [math.radians(v) for v in xs]

def rad_list_to_deg(xs: Sequence[float]) -> List[float]:
    return [math.degrees(v) for v in xs]

class HeadArmRobot:
    """
    High-level controller for the D1 head–arm chain.

    This class wraps the low-level Cython core (`HeadArmCore`) and exposes a
    simple Python API for controlling the 8-DOF chain:

        - 2 DOF active head (yaw, pitch)
        - 6 DOF arm

    Warning
    -------
    This API does not replace hardware safety. Always keep the physical
    emergency stop button within reach, and be prepared to press it
    immediately if the robot motion looks unsafe or unexpected.

    Example
    -------
    >>> import math
    >>> from beingbeyond_d1_sdk import HeadArmRobot, deg_list_to_rad
    >>>
    >>> urdf = "assets/beingbeyond_d1/robot_right_hand.urdf"
    >>> robot = HeadArmRobot(urdf_path=urdf, dev="/dev/ttyUSB0")
    >>>
    >>> q_init = deg_list_to_rad([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    >>> robot.set_positions(q_init)
    >>> robot.wait_until_reached(q_init)
    >>> robot.close()

    Or using a context manager:

    >>> with HeadArmRobot(urdf_path=urdf, dev="/dev/ttyUSB0") as robot:
    ...     q = deg_list_to_rad([0.0] * 8)
    ...     robot.set_positions(q)
    ...     robot.wait_until_reached(q)
    """

    def __init__(self, urdf_path: str, dev: str, baudrate: int = 1000000,
                    default_vel_rad: float = math.radians(60.0),
                    default_acc_rad: float = math.radians(60.0)) -> None:
        self._core = HeadArmCore(urdf_path, dev, baudrate=baudrate,
                                 default_vel_rad = default_vel_rad,
                                 default_acc_rad = default_acc_rad)

    @property
    def joint_names(self) -> List[str]:
        """
        Ordered joint names for the 8-DOF chain.
        """
        return self._core.get_joint_names()

    def set_profile(self, vels_rad: Sequence[float], accs_rad: Sequence[float]) -> None:
        """
        Configure per-joint motion profile limits.

        Parameters
        ----------
        vels_rad : Sequence[float]
            Joint velocity limits in rad/s. Must be 8-dim
            (2 DOF head + 6 DOF arm).
        accs_rad : Sequence[float]
            Joint acceleration limits in rad/s^2. Must be 8-dim
            (2 DOF head + 6 DOF arm).
        """
        self._core.set_profile(vels_rad, accs_rad)

    def set_positions(self, q_rad: Sequence[float]) -> None:
        """
        Set the target joint positions.

        Parameters
        ----------
        q_rad : Sequence[float]
            8 dim joint positions (rad)
            (2 DOF head + 6 DOF arm).
        """
        self._core.set_positions(q_rad)

    def get_positions_and_velocities(self) -> Tuple[List[float], List[float]]:
        """
        Read the current joint state from hardware.

        Returns
        -------
        q : List[float]
            Current joint positions in radians, 8-dim
            (2 DOF head + 6 DOF arm).
        dq : List[float]
            Current joint velocities in rad/s, 8-dim
            (2 DOF head + 6 DOF arm).
        """
        return self._core.get_positions_and_velocities()

    def get_positions(self) -> List[float]:
        """
        Read the current joint positions from hardware.

        Returns
        -------
        List[float]
            Current joint positions in radians, 8-dim
            (2 DOF head + 6 DOF arm).
        """
        return self._core.get_positions()

    def wait_until_reached(
        self,
        target_q_rad: Sequence[float],
        active_joint_indices: Optional[Iterable[int]] = None,
        pos_tol_deg: float = 5.0,
        vel_tol_deg_s: float = 5.0,
    ) -> Optional[float]:
        """
        Block until the robot has approximately reached the target posture.

        Parameters
        ----------
        target_q_rad : Sequence[float]
            Target joint positions in radians, 8-dim
            (2 DOF head + 6 DOF arm).
        active_joint_indices : Iterable[int], optional
            Indices of joints (0–7) to use for convergence checks.
            If None, all 8 joints are used.
        pos_tol_deg : float, optional
            Position tolerance in degrees. A joint is considered converged
            if |q_current - q_target| <= pos_tol_deg.
        vel_tol_deg_s : float, optional
            Velocity tolerance in deg/s. A joint i is considered at rest
            if its absolute velocity |dq[i]| <= vel_tol_deg_s.

        Returns
        -------
        float or None
            If convergence is detected, returns the elapsed time in seconds
            since the call. If timeout or lack of progress is detected,
            returns None.
        """
        return self._core.wait_until_reached(
            target_q_rad,
            active_joint_indices=active_joint_indices,
            pos_tol_deg=pos_tol_deg,
            vel_tol_deg_s=vel_tol_deg_s,
        )


    def close(self) -> None:
        """
        Safely home the head–arm chain and release the serial resource.

        This method commands a predefined homing sequence (2 DOF head +
        6 DOF arm), disables torque on all joints, and closes the underlying
        serial port. It is safe to call multiple times.
        """
        self._core.close()

    def __enter__(self):
        """
        Enter the context manager.

        Returns
        -------
        HeadArmRobot
            The robot instance itself.
        """
        return self

    def __exit__(self, exc_type, exc, tb):
        """
        Exit the context manager and automatically call `close()`.
        """
        self.close()

def _print_state(tag: str, robot: HeadArmRobot) -> None:
    q, dq = robot.get_positions_and_velocities()
    q_deg = [round(math.degrees(x), 3) for x in q]
    dq_deg = [round(math.degrees(x), 3) for x in dq]
    print(f"{tag} pos(deg): {q_deg}")
    print(f"{tag} vel(deg/s): {dq_deg}")


if __name__ == "__main__":
    urdf = "assets/beingbeyond_d1/robot_right_hand.urdf"
    robot = HeadArmRobot(urdf_path=urdf, dev="/dev/ttyUSB0", baudrate=1_000_000)
    try:
        _print_state("Initial", robot)

        # 设 profile 为 60deg/s, 60deg/s^2
        v_deg = 30.0
        a_deg = 30.0
        vels_rad = [math.radians(v_deg)] * 8
        accs_rad = [math.radians(a_deg)] * 8
        robot.set_profile(vels_rad, accs_rad)

        # 测试 1：到 [0,0,0,-90,90,0,0,0]
        target1_deg = [0.0, 0.0, 0.0, -90.0, 90.0, 0.0, 0.0, 0.0]
        target1_rad = deg_list_to_rad(target1_deg)
        robot.set_positions(target1_rad)
        dt1 = robot.wait_until_reached(target1_rad, active_joint_indices=range(8))
        print(f"Move to {target1_deg}, dt={dt1}")
        _print_state("After target1", robot)

        # 测试 2：回零
        zero_deg = [0.0] * 8
        zero_rad = [0.0] * 8
        robot.set_positions(zero_rad)
        dt2 = robot.wait_until_reached(zero_rad, active_joint_indices=range(8))
        print(f"Move to zero, dt={dt2}")
        _print_state("After zero", robot)

        # 测试 3：逐关节 ±30°
        print("\nPer-joint +/-30deg timing (1deg tol):")
        for j_idx, jname in enumerate(robot.joint_names):
            robot.set_positions(zero_rad)
            robot.wait_until_reached(zero_rad, active_joint_indices=[j_idx])

            # 0 -> +30
            tgt_p_deg = [0.0] * 8
            tgt_p_deg[j_idx] = 15.0
            tgt_p_rad = deg_list_to_rad(tgt_p_deg)
            robot.set_positions(tgt_p_rad)
            dt_up = robot.wait_until_reached(tgt_p_rad, active_joint_indices=[j_idx])

            # +30 -> -30
            tgt_m_deg = [0.0] * 8
            tgt_m_deg[j_idx] = -15.0
            tgt_m_rad = deg_list_to_rad(tgt_m_deg)
            robot.set_positions(tgt_m_rad)
            dt_down = robot.wait_until_reached(tgt_m_rad, active_joint_indices=[j_idx])

            v_up = 30.0 / dt_up if dt_up and dt_up > 0 else None
            v_down = 60.0 / dt_down if dt_down and dt_down > 0 else None

            print(f"{jname:20s} 0->+30: dt={dt_up}, v≈{v_up} deg/s")
            print(f"{'':20s} +30->-30: dt={dt_down}, v≈{v_down} deg/s")

    finally:
        robot.close()